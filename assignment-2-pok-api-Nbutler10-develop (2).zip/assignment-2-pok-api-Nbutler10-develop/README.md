# Assignment 2 - PokéAPI

This repository will contain your Android app which will consume data from the PokéAPI (https://pokeapi.co), allowing users to search for a Pokémon by name and view their details.
